#include <stdio.h>
#include <string.h>

main()
{
printf("Content- type: text/html\n\n");

printf("<html>\n");
printf("<head><title>An html page from a cgi</title></head>\n");
printf("<body bgcolor=\"#666666\">hello world</body>\n");
printf("</html>\n");
fflush(stdout);
}
