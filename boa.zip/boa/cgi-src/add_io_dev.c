/**
  ******************************************************************************
  * @par Copyright(c): ChengDu BinHong Science & Technology Co.,ltd
  * @file    add_io_dev.C
  * @author  chenxu
  * @version V1.0.0
  * @date    2015/12/15
  * @defgroup HTH
  * @ingroup  CGI
  * @brief   .
  * @par History
  * Date      Owner       BugID/CRID        Contents
  * 
  ****************************************************************************** 
  */

#include <stdio.h>
#include "cgic.h"
#include <string.h>
#include <stdlib.h>

#define PRINT_TO_WEB_EN        1
#define FORM_STRING_LEN_MAX    100


int cgiMain() 
{
	char MountPoint[FORM_STRING_LEN_MAX];
	char DevName[FORM_STRING_LEN_MAX];
	char DevType[FORM_STRING_LEN_MAX];
	char Protocal[FORM_STRING_LEN_MAX];
	char DevID[FORM_STRING_LEN_MAX];
	char ParamName[FORM_STRING_LEN_MAX];
	char ParamType[FORM_STRING_LEN_MAX];
	char AlarmCondition[FORM_STRING_LEN_MAX];
	char AlarmEnable[FORM_STRING_LEN_MAX];
	char SampleFrequency[FORM_STRING_LEN_MAX];


	cgiHeaderContentType("text/html");
	
#if(1 == PRINT_TO_WEB_EN) 
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>My CGI</TITLE></HEAD>\n");
	fprintf(cgiOut, "<BODY>");
#endif
	cgiFormString("MountPoint", MountPoint, FORM_STRING_LEN_MAX);
	cgiFormString("DevName", DevName, FORM_STRING_LEN_MAX);
	cgiFormString("DevType", DevType, FORM_STRING_LEN_MAX);
	cgiFormString("Protocal", Protocal, FORM_STRING_LEN_MAX);
	cgiFormString("DevID", DevID, FORM_STRING_LEN_MAX);
	cgiFormString("ParamName", ParamName, FORM_STRING_LEN_MAX);
	cgiFormString("ParamType", ParamType, FORM_STRING_LEN_MAX);
	cgiFormString("AlarmCondition", AlarmCondition, FORM_STRING_LEN_MAX);
	cgiFormString("AlarmEnable", AlarmEnable, FORM_STRING_LEN_MAX);
	cgiFormString("SampleFrequency", SampleFrequency, FORM_STRING_LEN_MAX);


#if(1 == PRINT_TO_WEB_EN) 
	fprintf(cgiOut, "<H4>this is a test show</H4>");
	
	fprintf(cgiOut, "<H4>%s</H4>",MountPoint);
	fprintf(cgiOut, "<H4>%s</H4>",DevName);
	fprintf(cgiOut, "<H4>%s</H4>",DevType);
	fprintf(cgiOut, "<H4>%s</H4>",Protocal);
	fprintf(cgiOut, "<H4>%s</H4>",DevID);
	fprintf(cgiOut, "<H4>%s</H4>",ParamName);
	fprintf(cgiOut, "<H4>%s</H4>",ParamType);
	fprintf(cgiOut, "<H4>%s</H4>",AlarmCondition);
	fprintf(cgiOut, "<H4>%s</H4>",AlarmEnable);
	fprintf(cgiOut, "<H4>%s</H4>",SampleFrequency);


	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "</HTML>\n");
#endif

	// �Ѿ��õ�������Ҫ�Ĳ��������Խ��к���������
	  
	return 0;
}


