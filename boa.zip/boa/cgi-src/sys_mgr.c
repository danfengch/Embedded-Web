/**
  ******************************************************************************
  * @par Copyright(c): ChengDu BinHong Science & Technology Co.,ltd
  * @file    sys_mgr.C
  * @author  chenxu
  * @version V1.0.0
  * @date    2015/12/15
  * @defgroup HTH
  * @ingroup  CGI
  * @brief   .
  * @par History
  * Date      Owner       BugID/CRID        Contents
  * 
  ****************************************************************************** 
  */

#include <stdio.h>
#include "cgic.h"
#include <string.h>
#include <stdlib.h>

#define PRINT_TO_WEB_EN        1
#define FORM_STRING_LEN_MAX    100


int cgiMain() 
{
	char Lan1_IP[FORM_STRING_LEN_MAX];
	char Lan1_Mask[FORM_STRING_LEN_MAX];
	char Lan1_GateWay[FORM_STRING_LEN_MAX];
	char Lan1_MCFlag[FORM_STRING_LEN_MAX];
	
	char Lan2_IP[FORM_STRING_LEN_MAX];
	char Lan2_Mask[FORM_STRING_LEN_MAX];
	char Lan2_GateWay[FORM_STRING_LEN_MAX];
	char Lan2_MCFlag[FORM_STRING_LEN_MAX];
	
	char MainServer_IP[FORM_STRING_LEN_MAX];
	char MainServer_Mask[FORM_STRING_LEN_MAX];
	char MainServer_GateWay[FORM_STRING_LEN_MAX];
	char MainServer_Port[FORM_STRING_LEN_MAX];
	
	char BackupServer_IP[FORM_STRING_LEN_MAX];
	char BackupServer_Mask[FORM_STRING_LEN_MAX];
	char BackupServer_GateWay[FORM_STRING_LEN_MAX];
	char BackupServer_Port[FORM_STRING_LEN_MAX];
	
	char ReplaceTime[FORM_STRING_LEN_MAX];
	char SignInCycle[FORM_STRING_LEN_MAX];
	char HeartBeatCycle[FORM_STRING_LEN_MAX];

	cgiHeaderContentType("text/html");
	
//#if(1 == PRINT_TO_WEB_EN) 
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>My CGI</TITLE></HEAD>\n");
	fprintf(cgiOut, "<BODY>");
//#endif
	cgiFormString("Lan1_IP", Lan1_IP, FORM_STRING_LEN_MAX);
	cgiFormString("Lan1_Mask", Lan1_Mask, FORM_STRING_LEN_MAX);
	cgiFormString("Lan1_GateWay", Lan1_GateWay, FORM_STRING_LEN_MAX);
	cgiFormString("Lan1_MCFlag", Lan1_MCFlag, FORM_STRING_LEN_MAX);
	
	cgiFormString("Lan2_IP", Lan2_IP, FORM_STRING_LEN_MAX);
	cgiFormString("Lan2_Mask", Lan2_Mask, FORM_STRING_LEN_MAX);
	cgiFormString("Lan2_GateWay", Lan2_GateWay, FORM_STRING_LEN_MAX);
	cgiFormString("Lan2_MCFlag", Lan2_MCFlag, FORM_STRING_LEN_MAX);
	
	cgiFormString("MainServer_IP", MainServer_IP, FORM_STRING_LEN_MAX);
	cgiFormString("MainServer_Mask", MainServer_Mask, FORM_STRING_LEN_MAX);
	cgiFormString("MainServer_GateWay", MainServer_GateWay, FORM_STRING_LEN_MAX);
	cgiFormString("MainServer_Port", MainServer_Port, FORM_STRING_LEN_MAX);
	
	cgiFormString("BackupServer_IP", BackupServer_IP, FORM_STRING_LEN_MAX);
	cgiFormString("BackupServer_Mask", BackupServer_Mask, FORM_STRING_LEN_MAX);
	cgiFormString("BackupServer_GateWay", BackupServer_GateWay, FORM_STRING_LEN_MAX);
	cgiFormString("BackupServer_Port", BackupServer_Port, FORM_STRING_LEN_MAX);
	
	cgiFormString("ReplaceTime", ReplaceTime, FORM_STRING_LEN_MAX);
	cgiFormString("SignInCycle", SignInCycle, FORM_STRING_LEN_MAX);
	cgiFormString("HeartBeatCycle", HeartBeatCycle, FORM_STRING_LEN_MAX);

//#if(1 == PRINT_TO_WEB_EN) 
	fprintf(cgiOut, "<H4>this is a test show</H4>");
	
	fprintf(cgiOut, "<H4>%s</H4>",Lan1_IP);
	fprintf(cgiOut, "<H4>%s</H4>",Lan1_Mask);
	fprintf(cgiOut, "<H4>%s</H4>",Lan1_GateWay);
	fprintf(cgiOut, "<H4>%s</H4>",Lan1_MCFlag);
	
	fprintf(cgiOut, "<H4>%s</H4>",Lan2_IP);
	fprintf(cgiOut, "<H4>%s</H4>",Lan2_Mask);
	fprintf(cgiOut, "<H4>%s</H4>",Lan2_GateWay);
	fprintf(cgiOut, "<H4>%s</H4>",Lan2_MCFlag);
	
	fprintf(cgiOut, "<H4>%s</H4>",MainServer_IP);
	fprintf(cgiOut, "<H4>%s</H4>",MainServer_Mask);
	fprintf(cgiOut, "<H4>%s</H4>",MainServer_GateWay);
	fprintf(cgiOut, "<H4>%s</H4>",MainServer_Port);
	
	fprintf(cgiOut, "<H4>%s</H4>",BackupServer_IP);
	fprintf(cgiOut, "<H4>%s</H4>",BackupServer_Mask);
	fprintf(cgiOut, "<H4>%s</H4>",BackupServer_GateWay);
	fprintf(cgiOut, "<H4>%s</H4>",BackupServer_Port);
	
	fprintf(cgiOut, "<H4>%s</H4>",ReplaceTime);
	fprintf(cgiOut, "<H4>%s</H4>",SignInCycle);
	fprintf(cgiOut, "<H4>%s</H4>",HeartBeatCycle);

	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "</HTML>\n");
//#endif

	// �Ѿ��õ�������Ҫ�Ĳ��������Խ��к���������
	/*�����м��ַ���:
	  1)��cgiģ���ｫ����д��XML�ļ���Ȼ��֪ͨAPPȥ���»�ȡ������
	  2)������ȫ�����ݸ�APP��Ȼ����APPȥ����XML�ļ���

	  ��Ҫע�⼸��:
	  1)��Щ����������Ҫ���������忨������Ч��
	  2)��APP�����ʹ��������������ÿ�ζ���Ҫ���¶�ȡ�����Ǿ��¼�����������ص��ڴ棬Ȼ��ֻ�����µ�
	  �������������������¶�ȡ?*/
	  
	return 0;
}


